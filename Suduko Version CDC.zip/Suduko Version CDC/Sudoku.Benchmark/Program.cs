using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Running;
using Microsoft.Extensions.Configuration;
using Sudoku.Norvig;
using Sudoku.Shared;
//using Humanizer;


namespace Sudoku.Benchmark
{
    class Program
    {

#if DEBUG
        public static bool IsDebug = true;
#else
        public static bool IsDebug = false;
#endif

        static IConfiguration Configuration;

        static void Main(string[] args)
        {

            Console.WriteLine("Benchmarking GrilleSudoku Solvers");


            // Configuration Builder
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            Configuration = builder.Build();

            PythonConfiguration pythonConfig = null;

            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                pythonConfig = Configuration.GetSection("PythonConfig:OSX").Get<PythonConfiguration>();

            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.FreeBSD))
            {
                pythonConfig = Configuration.GetSection("PythonConfig:Linux").Get<PythonConfiguration>();
                //LinuxInstaller.InstallPath = "/root/.pyenv/versions/3.10.5";
                //LinuxInstaller.PythonDirectoryName = "/root/.pyenv/versions/3.10.5/bin";
                //LinuxInstaller.LibFileName = "/root/.pyenv/versions/3.10.5/lib/libpython3.10.so";
            }

            if (pythonConfig != null)
            {
                Console.WriteLine("Customizing MacOs/Linux Python Install from appsettings.json file");
                if (!string.IsNullOrEmpty(pythonConfig.InstallPath))
                {
                    MacInstaller.InstallPath = pythonConfig.InstallPath;
                }
                if (!string.IsNullOrEmpty(pythonConfig.PythonDirectoryName))
                {
                    MacInstaller.PythonDirectoryName = pythonConfig.PythonDirectoryName;
                }
                if (!string.IsNullOrEmpty(pythonConfig.LibFileName))
                {
                    MacInstaller.LibFileName = pythonConfig.LibFileName;
                }
            }

            while (true)
            {
                if (IsDebug)
                {
                    if (RunMenu())
                    {
                        break;
                    }

                }
                else
                {
                    try
                    {
                        if (RunMenu())
                        {
                            break;
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
            }
        }


        private static bool RunMenu()
        {
            Console.WriteLine("Select Mode: \n1-Single Solver Test, \n2-Benchmarks, \n3-Custom Benchmark, \n4-Norvig, \n5-Exit program");
            var strMode = Console.ReadLine();
            int.TryParse(strMode, out var intMode);

            switch (intMode)
            {
                case 1:
                    SingleSolverTest();
                    break;
                case 2:
                    Benchmark();
                    break;
                case 3:
                    CustomBenchmark();
                    break;
                case 4:
                    Norvig();
                    break;
                default:
                    return true;
            }

            return false;
        }


        private static void Benchmark()
        {
            Console.WriteLine("Select Benchmark Type: \n1-Quick Benchmark (Easy, 2 Sudokus, 10s max per sudoku, Single invocation), \n2-Quick Benchmark (Medium, 10 Sudokus, 20s max per sudoku, Single invocation), \n3-Quick Benchmark (Hard, 10 Sudokus, 30s max per sudoku, Single invocation), \n4-Complete Benchmark (All difficulties, 1 mn max per sudoku, several invocations), \n5-Return");
            var strMode = Console.ReadLine();
            int.TryParse(strMode, out var intMode);
            //Console.SetBufferSize(130, short.MaxValue - 100);
            switch (intMode)
            {
                case 1:
                    var tempEasy = new QuickBenchmarkSolversEasy();

                    //               if (IsDebug)
                    //               {
                    //	BenchmarkRunner.Run<QuickBenchmarkSolversEasy>(new DebugInProcessConfig());
                    //}
                    //               else
                    //               {
                    //	BenchmarkRunner.Run<QuickBenchmarkSolversEasy>();
                    //}
                    BenchmarkRunner.Run<QuickBenchmarkSolversEasy>();
                    break;
                case 2:
                    //Init solvers
                    var tempMedium = new QuickBenchmarkSolversMedium();
                    //BenchmarkRunner.Run<QuickBenchmarkSolvers>(new DebugInProcessConfig());
                    BenchmarkRunner.Run<QuickBenchmarkSolversMedium>();
                    break;
                case 3:
                    //Init solvers
                    var tempHard = new QuickBenchmarkSolversHard();
                    //BenchmarkRunner.Run<QuickBenchmarkSolvers>(new DebugInProcessConfig());
                    BenchmarkRunner.Run<QuickBenchmarkSolversHard>();
                    break;
                case 4:
                    //Init solvers
                    var temp2 = new CompleteBenchmarkSolvers();
                    BenchmarkRunner.Run<CompleteBenchmarkSolvers>();
                    break;
                default:
                    break;
            }

        }



        private static void SingleSolverTest()
        {
            var solvers = Shared.SudokuGrid.GetSolvers();
            Console.WriteLine("Select difficulty: 1-Easy, 2-Medium, 3-Hard");
            var strDiff = Console.ReadLine();
            int.TryParse(strDiff, out var intDiff);
            SudokuDifficulty difficulty = SudokuDifficulty.Hard;
            switch (intDiff)
            {
                case 1:
                    difficulty = SudokuDifficulty.Easy;
                    break;
                case 2:
                    difficulty = SudokuDifficulty.Medium;
                    break;
                case 3:
                    difficulty = SudokuDifficulty.Hard;
                    break;
                default:
                    break;
            }
            //SudokuDifficulty difficulty = intDiff switch
            //{
            //    1 => SudokuDifficulty.Easy,
            //    2 => SudokuDifficulty.Medium,
            //    _ => SudokuDifficulty.Hard
            //};

            var sudokus = SudokuHelper.GetSudokus(difficulty);

            Console.WriteLine($"Choose a puzzle index between 1 and {sudokus.Count}");
            var strIdx = Console.ReadLine();
            int.TryParse(strIdx, out var intIdx);
            var targetSudoku = sudokus[intIdx - 1];

            Console.WriteLine("Chosen Puzzle:");
            Console.WriteLine(targetSudoku.ToString());

            Console.WriteLine("Choose a solver:");
            var solverList = solvers.ToList();
            for (int i = 0; i < solvers.Count(); i++)
            {
                Console.WriteLine($"{(i + 1).ToString(CultureInfo.InvariantCulture)} - {solverList[i].Key}");
            }
            var strSolver = Console.ReadLine();
            int.TryParse(strSolver, out var intSolver);
            var solver = solverList[intSolver - 1].Value.Value;

            var cloneSudoku = targetSudoku.CloneSudoku();
            var sw = Stopwatch.StartNew();

            int[,] monTableau2D = new int[9, 9]; // Remplace par la vraie initialisation des données

            SudokuGrid grid = SudokuGrid.FromArray(monTableau2D);

            cloneSudoku = solver.Solve(cloneSudoku);



            var elapsed = sw.Elapsed;
            if (!cloneSudoku.IsValid(targetSudoku))
            {
                Console.WriteLine($"Invalid Solution : Solution has {cloneSudoku.NbErrors(targetSudoku)} errors");
                Console.WriteLine("Invalid solution:");
            }
            else
            {
                Console.WriteLine("Valid solution:");
            }

            Console.WriteLine(cloneSudoku.ToString());
            Console.WriteLine($"Time to solution: {elapsed.TotalMilliseconds} ms");

        }


        private static void CustomBenchmark()
        {
            var solvers = Shared.SudokuGrid.GetSolvers();
            Console.WriteLine("Select difficulty: 1-Easy, 2-Medium, 3-Hard");
            var strDiff = Console.ReadLine();
            int.TryParse(strDiff, out var intDiff);
            SudokuDifficulty difficulty = SudokuDifficulty.Hard;

            switch (intDiff)
            {
                case 1:
                    difficulty = SudokuDifficulty.Easy;
                    break;
                case 2:
                    difficulty = SudokuDifficulty.Medium;
                    break;
                case 3:
                    difficulty = SudokuDifficulty.Hard;
                    break;
                default:
                    break;
            }

            var sudokus = SudokuHelper.GetSudokus(difficulty);

            Console.WriteLine($"Choose up to 10 puzzle indices between 1 and {sudokus.Count}, separated by spaces (e.g., '1 5 10')");
            var strIdx = Console.ReadLine();
            var indices = strIdx.Split(' ').Select(x => int.Parse(x.Trim()) - 1).Take(10).ToList();

            Console.WriteLine("Choose a solver:");
            var solverList = solvers.ToList();
            for (int i = 0; i < solvers.Count(); i++)
            {
                Console.WriteLine($"{i + 1} - {solverList[i].Key}");
            }
            var strSolver = Console.ReadLine();
            int.TryParse(strSolver, out var intSolver);
            var solver = solverList[intSolver - 1].Value.Value;

            List<double> executionTimes = new List<double>();

            foreach (var idx in indices)
            {
                var targetSudoku = sudokus[idx];
                Console.WriteLine($"\n--- Resolving Sudoku index {idx + 1} ---");

                for (int i = 0; i < 6; i++)
                {
                    if (i == 0) continue; // Ignore the first run
                    var cloneSudoku = targetSudoku.CloneSudoku();
                    var sw = Stopwatch.StartNew();

                    int[,] monTableau2D = new int[9, 9]; // Remplace par la vraie initialisation des données

                    SudokuGrid grid = SudokuGrid.FromArray(monTableau2D);


                    cloneSudoku = solver.Solve(cloneSudoku);

                    sw.Stop();
                    executionTimes.Add(sw.Elapsed.TotalMilliseconds);
                }
            }

            Console.WriteLine($"\n--- Global Statistics ---");
            Console.WriteLine($"Average Time: {executionTimes.Average():F2} ms");
            Console.WriteLine($"Median Time: {CalculateMedian(executionTimes):F2} ms");
        }

        private static double CalculateMedian(List<double> values)
        {
            values.Sort();
            if (values.Count % 2 == 0)
            {
                return (values[values.Count / 2 - 1] + values[values.Count / 2]) / 2.0;
            }
            else
            {
                return values[values.Count / 2];
            }
        }


        private static void Norvig()
        {
            // Demander à l'utilisateur de choisir le niveau de difficulté
            Console.WriteLine("Choisissez le niveau de difficulté :");
            Console.WriteLine("1 - Facile");
            Console.WriteLine("2 - Moyen");
            Console.WriteLine("3 - Difficile");

            int difficulty = int.Parse(Console.ReadLine());  // Lire la sélection de l'utilisateur

            var solver = new NorvigSolver();  // Initialisation du solveur

            // Générer le puzzle en fonction du niveau de difficulté choisi
            string puzzle = GeneratePuzzle(difficulty);

            // Appeler la méthode Solve avec la chaîne et récupérer le tableau résolu
            bool solved = solver.Solve(puzzle);

            if (solved)
            {
                var solvedBoard = solver.GetSolvedBoard();
                Console.WriteLine("Sudoku résolu avec succès !");
                // Afficher le board résolu
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        Console.Write(solvedBoard[i, j] + " ");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Échec de la résolution.");
            }
        }

        private static string GeneratePuzzle(int difficulty)
        {
            var solver = new NorvigSolver();
            int[,] solvedBoard = solver.GenerateCompletedBoard();  // Générer un Sudoku valide

            // Convertir le tableau en chaîne pour faciliter la manipulation
            string puzzle = NorvigSolver.ConvertBoardToString(solvedBoard);

            // Enlever les chiffres en fonction du niveau de difficulté
            return RemoveDigits(puzzle, difficulty);
        }

        private static string RemoveDigits(string puzzle, int difficulty)
        {
            Random rand = new Random();
            int emptyCells = difficulty switch
            {
                1 => 36,  // Facile : 36 cellules vides
                2 => 45,  // Moyen : 45 cellules vides
                3 => 54,  // Difficile : 54 cellules vides
                _ => 45   // Par défaut : Moyen
            };

            List<int> positions = new List<int>();
            for (int i = 0; i < puzzle.Length; i++)
            {
                if (puzzle[i] != ' ')
                    positions.Add(i);
            }

            // Mélanger et enlever les chiffres
            var randomPositions = positions.OrderBy(x => rand.Next()).Take(emptyCells).ToList();
            char[] puzzleChars = puzzle.ToCharArray();
            foreach (var pos in randomPositions)
            {
                puzzleChars[pos] = '0';  // Remplacer par un 0 (case vide)
            }

            return new string(puzzleChars);
        }

    }



}

