﻿namespace Sudoku.Benchmark
{
    public enum SudokuDifficulty
    {
        Easy,
        Medium,
        Hard
    }
}