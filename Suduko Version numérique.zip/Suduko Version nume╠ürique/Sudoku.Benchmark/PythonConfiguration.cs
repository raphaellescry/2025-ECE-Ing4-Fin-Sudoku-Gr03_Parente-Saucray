namespace Sudoku.Benchmark;

public class PythonConfiguration
{
	public string InstallPath { get; set; }
	public string PythonDirectoryName { get; set; }
	public string LibFileName { get; set; }
}